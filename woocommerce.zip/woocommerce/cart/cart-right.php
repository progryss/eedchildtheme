<?php do_action('woocommerce_before_cart_collaterals'); ?>
    <?php
    $cart = WC()->cart;
    $available = array();
    $subtotal = $cart->get_subtotal();
    $item_total = $cart->get_cart_contents_total();
    $discount_html = '';
    $discount_applied = false;

    // Get applied coupons
    $applied_coupons = WC()->cart->get_applied_coupons();

    if (!empty($applied_coupons)) {
        $discount_applied = true;
        foreach ($applied_coupons as $coupon_code) {
            $coupon = new WC_Coupon($coupon_code);
            $discount_amount = WC()->cart->get_coupon_discount_amount($coupon_code, $item_total);

            $discount_html .= '<div class="discount-item d-flex justify-content-between py-1">';
            $discount_html .= '<div class="ff-bold rfs-6 lh-sm">' . get_woocommerce_currency_symbol() . number_format($discount_amount, 2) . '</div>';
            $discount_html .= '</div>';
        }
    }

    // Check for custom rule discounts
    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
        $discount = apply_filters('advanced_woo_discount_rules_get_cart_item_discount_details', false, $cart_item);
        if (!empty($discount['applied_rules'])) {
            $discount_applied = true;
            $title = $discount['applied_rules'][0]['title'];
            $saved = $discount['applied_rules'][0]["discount"]['discount_price'] * $discount['applied_rules'][0]["discount"]['discount_quantity'];
            $saved = get_woocommerce_currency_symbol() . number_format($saved, 2);

            if ((int)$discount["discounted_price"] === 0) {
                $item_total += $discount["initial_price"];
            }

            $discount_html .= '<div class="discount-item d-flex justify-content-between py-1">';
            $discount_html .= '<div><span class="text-secondary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16"><path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/></svg></span>';
            $discount_html .= '<span class="ps-2 rfs-6 lh-sm">' . $title . '</span></div>';
            $discount_html .= '<div class="ff-bold rfs-6 lh-sm">' . $saved . '</div></div>';
        }
    }

    // Start final HTML output
    $html = '';

    // If discount applied, show cost before discounts
    if ($discount_applied) {
        $html .= '<div class="cost-before-discount d-flex justify-content-between mb-2">
            <span class="">Cost before discounts (ex. VAT)</span>
            <span class="">' . wc_price($subtotal) . '</span>
        </div>';
    }

    // Always show "Discounts you’ve earned..." section
    $html .= '<div class="discount-items">';
    $html .= '<div class="text-secondary-discounts">Discounts you\'ve earned on this order</div>';

    if ($discount_applied) {
        $html .= $discount_html;
    } else {
        $html .= '<div class="no-discounts-text">No discounts</div>';
    }

    $html .= '</div>';

    // Suggest unlocked offers if below threshold
    // if ($item_total < 150) {
    //     $more = 150 - $item_total;
    //     $more = get_woocommerce_currency_symbol() . number_format($more, 2);
    //     $available[] = 'Spend <span class="ff-bold">' . $more . '</span> more for <span class="ff-bold">FREE delivery</span>';
    //     $available[] = 'Spend <span class="ff-bold">' . $more . '</span> more for <span class="ff-bold">FREE logo setup</span>';
    // }

    // if (!empty($available)) {
    //     $html .= '<div class="available-discounts bg-light p-3 rounded">';
    //     $html .= '<div class="rfs-6 ff-bold lh-sm text-grey mb-2">You could unlock more:</div>';
    //     foreach ($available as $note) {
    //         $html .= '<div class="rfs-6 lh-sm text-muted mb-1"> 
    //             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#727276" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
    //               <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3z"></path>
    //             </svg> ' . $note . '</div>';
    //     }
    //     $html .= '</div>';
    // }

    // Show final price if discount applied
    if ($discount_applied) {
        $discount_total = $cart->get_discount_total();
        $after_discount = $subtotal - $discount_total;

        $html .= '<div class="cost-after-discount">
            <span class="">Cost after discounts (ex. VAT)</span>
            <span class="">' . wc_price($after_discount) . '</span>
        </div>';
    }

    echo $html;
    ?>



        <div class="cart-collaterals">
          <!-- start Shipping -->
          <div class="shipping-totals custom-shipping">
            <table cellspacing="0" class="shop_table shop_table_responsive">
              <?php if (WC()->cart->needs_shipping() && WC()->cart->show_shipping()): ?>

                <?php do_action('woocommerce_cart_totals_before_shipping'); ?>

                <?php wc_cart_totals_shipping_html(); ?>

                <?php do_action('woocommerce_cart_totals_after_shipping'); ?>

              <?php elseif (WC()->cart->needs_shipping() && 'yes' === get_option('woocommerce_enable_shipping_calc')): ?>

                <tr class="shipping">
                  <th><?php esc_html_e('Shipping', 'woocommerce'); ?></th>
                  <td data-title="<?php esc_attr_e('Shipping', 'woocommerce'); ?>">
                    <?php woocommerce_shipping_calculator(); ?></td>
                </tr>

              <?php endif; ?>

            </table>
          </div>
          <!-- End Shipping -->
          <div class="coupon-heading">Voucher</div>
          <?php if (wc_coupons_enabled()) { ?>
            <div class="coupon">
              <label for="coupon_code" class="screen-reader-text"><?php esc_html_e('Coupon:', 'woocommerce'); ?></label>
              <input type="text" name="coupon_code" class="input-text" id="coupon_code" value=""
                placeholder="<?php esc_attr_e('Coupon code', 'woocommerce'); ?>" /> <button type="submit"
                class="button<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>"
                name="apply_coupon"
                value="<?php esc_attr_e('Apply coupon', 'woocommerce'); ?>"><?php esc_html_e('Apply', 'woocommerce'); ?></button>
              <?php do_action('woocommerce_cart_coupon'); ?>
            </div>
          <?php } ?>
          <?php
          /**
           * Cart collaterals hook.
           *
           * @hooked woocommerce_cross_sell_display
           * @hooked woocommerce_cart_totals - 10
           */
          do_action('woocommerce_cart_collaterals');
          ?>
          <div class="payment-options">
            Secure payments:
            <svg width="214" height="24" viewBox="0 0 214 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="0.5" y="0.5" width="34" height="23" rx="2" fill="white" stroke="#D9D9D9"></rect>
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M10.6907 16.2582H8.57037L6.98038 10.1924C6.90492 9.91334 6.74468 9.66666 6.50897 9.5504C5.92074 9.25823 5.27255 9.0257 4.56543 8.90843V8.67489H7.9811C8.45251 8.67489 8.80607 9.0257 8.865 9.43313L9.68997 13.8086L11.8093 8.67489H13.8707L10.6907 16.2582ZM15.0492 16.2582H13.0467L14.6956 8.67489H16.6981L15.0492 16.2582ZM19.2888 10.7757C19.3477 10.3673 19.7013 10.1337 20.1138 10.1337C20.762 10.0751 21.468 10.1924 22.0573 10.4835L22.4109 8.85081C21.8216 8.61727 21.1734 8.5 20.5852 8.5C18.6416 8.5 17.2274 9.55041 17.2274 11.0082C17.2274 12.1173 18.2292 12.6996 18.9363 13.0504C19.7013 13.4002 19.9959 13.6338 19.937 13.9835C19.937 14.5082 19.3477 14.7418 18.7595 14.7418C18.0524 14.7418 17.3453 14.5669 16.6981 14.2747L16.3445 15.9085C17.0517 16.1996 17.8167 16.3169 18.5238 16.3169C20.703 16.3745 22.0573 15.3251 22.0573 13.75C22.0573 11.7665 19.2888 11.6502 19.2888 10.7757ZM29.0654 16.2582L27.4755 8.67489H25.7676C25.4141 8.67489 25.0605 8.90843 24.9427 9.25823L21.9984 16.2582H24.0598L24.4712 15.1502H27.0041L27.2398 16.2582H29.0654ZM26.0622 10.7171L26.6505 13.5751H25.0015L26.0622 10.7171Z"
                fill="#172B85"></path>
              <rect x="45.5" y="0.5" width="34" height="23" rx="2" fill="#1F72CD" stroke="#D9D9D9"></rect>
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M51.307 8.43066L48.0439 15.8641H51.9503L52.4346 14.6789H53.5415L54.0258 15.8641H58.3256V14.9595L58.7087 15.8641H60.9329L61.3161 14.9404V15.8641H70.2585L71.3458 14.7097L72.364 15.8641L76.957 15.8737L73.6836 12.1681L76.957 8.43066H72.4352L71.3767 9.56375L70.3906 8.43066H60.6625L59.8271 10.3493L58.9722 8.43066H55.074V9.30447L54.6403 8.43066H51.307ZM64.6607 9.48622H69.7958L71.3664 11.2327L72.9877 9.48622H74.5583L72.1719 12.1671L74.5583 14.8171H72.9164L71.3458 13.0503L69.7163 14.8171H64.6607V9.48622ZM65.9288 11.5643V10.5906V10.5897H69.133L70.5311 12.1469L69.0711 13.7127H65.9288V12.6496H68.7303V11.5643H65.9288ZM52.0628 9.48622H53.967L56.1314 14.5269V9.48622H58.2173L59.889 13.1004L61.4297 9.48622H63.5052V14.8202H62.2423L62.232 10.6405L60.3908 14.8202H59.2611L57.4097 10.6405V14.8202H54.8116L54.3191 13.6244H51.6581L51.1665 14.8192H49.7745L52.0628 9.48622ZM52.1124 12.5189L52.9891 10.3887L53.8648 12.5189H52.1124Z"
                fill="white"></path>
              <rect x="90.5" y="0.5" width="33" height="23" rx="2" fill="white" stroke="#D9D9D9"></rect>
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M107.317 17.5462C106.019 18.6506 104.337 19.3174 102.498 19.3174C98.3946 19.3174 95.0684 15.9979 95.0684 11.9031C95.0684 7.80826 98.3946 4.48877 102.498 4.48877C104.337 4.48877 106.019 5.15551 107.317 6.25997C108.614 5.15552 110.297 4.48879 112.136 4.48879C116.239 4.48879 119.565 7.80829 119.565 11.9031C119.565 15.9979 116.239 19.3174 112.136 19.3174C110.297 19.3174 108.614 18.6506 107.317 17.5462Z"
                fill="#ED0006"></path>
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M107.316 17.5462C108.914 16.1863 109.927 14.1627 109.927 11.9031C109.927 9.64341 108.914 7.61986 107.316 6.25994C108.614 5.1555 110.297 4.48877 112.135 4.48877C116.239 4.48877 119.565 7.80826 119.565 11.9031C119.565 15.9979 116.239 19.3174 112.135 19.3174C110.297 19.3174 108.614 18.6506 107.316 17.5462Z"
                fill="#F9A000"></path>
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M107.316 17.5464C108.914 16.1865 109.927 14.163 109.927 11.9033C109.927 9.64371 108.914 7.62017 107.316 6.26025C105.719 7.62017 104.706 9.64371 104.706 11.9033C104.706 14.163 105.719 16.1865 107.316 17.5464Z"
                fill="#FF5E00"></path>
              <rect x="134.5" y="0.5" width="34" height="23" rx="2" fill="white" stroke="#D9D9D9"></rect>
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M150.53 15.7585V12.7375H152.089C152.728 12.7375 153.267 12.5234 153.707 12.1012L153.812 11.9942C154.615 11.12 154.562 9.75817 153.707 8.94941C153.279 8.52125 152.693 8.28932 152.089 8.30122H149.586V15.7585H150.53ZM150.53 11.8217V9.21702H152.113C152.453 9.21702 152.775 9.34785 153.015 9.58572C153.525 10.0853 153.537 10.9178 153.045 11.4352C152.804 11.6909 152.464 11.8336 152.113 11.8217H150.53ZM158.214 11.0546C157.81 10.6799 157.259 10.4896 156.561 10.4896C155.664 10.4896 154.99 10.8227 154.545 11.4828L155.377 12.012C155.682 11.5601 156.098 11.3341 156.626 11.3341C156.96 11.3341 157.282 11.459 157.534 11.6849C157.78 11.899 157.921 12.2083 157.921 12.5353V12.7554C157.558 12.5532 157.1 12.4461 156.538 12.4461C155.881 12.4461 155.354 12.6007 154.961 12.9159C154.568 13.2311 154.369 13.6474 154.369 14.1766C154.357 14.6583 154.562 15.1162 154.926 15.4255C155.295 15.7585 155.764 15.925 156.315 15.925C156.966 15.925 157.481 15.6336 157.874 15.0508H157.915V15.7585H158.818V12.6126C158.818 11.9525 158.619 11.4292 158.214 11.0546ZM155.653 14.8188C155.459 14.6761 155.342 14.4442 155.342 14.1944C155.342 13.9149 155.471 13.683 155.723 13.4987C155.981 13.3143 156.304 13.2192 156.685 13.2192C157.212 13.2132 157.623 13.3321 157.916 13.57C157.916 13.9744 157.757 14.3253 157.447 14.6226C157.165 14.908 156.784 15.0686 156.386 15.0686C156.122 15.0745 155.864 14.9853 155.653 14.8188ZM160.846 18.0004L164 10.6562H162.974L161.514 14.3194H161.497L160.002 10.6562H158.976L161.045 15.4314L159.873 18.0004H160.846Z"
                fill="#3C4043"></path>
              <path
                d="M147.272 12.0831C147.272 11.7917 147.249 11.5003 147.202 11.2148H143.222V12.8621H145.502C145.408 13.3914 145.103 13.8671 144.658 14.1644V15.2349H146.018C146.815 14.4915 147.272 13.3914 147.272 12.0831Z"
                fill="#4285F4"></path>
              <path
                d="M143.222 16.2696C144.359 16.2696 145.321 15.889 146.018 15.2349L144.658 14.1645C144.277 14.4261 143.791 14.5748 143.222 14.5748C142.12 14.5748 141.188 13.8195 140.854 12.8086H139.453V13.9147C140.168 15.3598 141.628 16.2696 143.222 16.2696Z"
                fill="#34A853"></path>
              <path
                d="M140.854 12.8088C140.678 12.2796 140.678 11.7027 140.854 11.1675V10.0674H139.453C138.849 11.2746 138.849 12.7018 139.453 13.909L140.854 12.8088Z"
                fill="#FBBC04"></path>
              <path
                d="M143.222 9.40114C143.826 9.38925 144.406 9.62117 144.84 10.0434L146.047 8.81836C145.28 8.09285 144.271 7.69442 143.222 7.70631C141.628 7.70631 140.168 8.62211 139.453 10.0672L140.854 11.1733C141.188 10.1564 142.12 9.40114 143.222 9.40114Z"
                fill="#EA4335"></path>
              <rect x="179.5" y="0.5" width="34" height="23" rx="2" fill="white" stroke="#D9D9D9"></rect>
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M187.346 8.93296C187.816 8.97261 188.286 8.69506 188.58 8.34316C188.869 7.98135 189.06 7.49563 189.011 7C188.595 7.01983 188.081 7.27755 187.787 7.63936C187.518 7.95161 187.287 8.45715 187.346 8.93296ZM192.938 15.3167V7.5898H195.802C197.281 7.5898 198.314 8.62071 198.314 10.1274C198.314 11.6341 197.261 12.675 195.763 12.675H194.123V15.3167H192.938ZM189.006 9.02715C188.592 9.00302 188.214 9.15321 187.909 9.27452C187.712 9.35259 187.546 9.41869 187.42 9.41869C187.278 9.41869 187.104 9.34905 186.91 9.27086L186.91 9.27086L186.91 9.27086L186.91 9.27086C186.655 9.1684 186.364 9.05126 186.058 9.05688C185.358 9.0668 184.707 9.46826 184.35 10.1076C183.615 11.3863 184.159 13.2797 184.869 14.3205C185.216 14.8359 185.632 15.4009 186.181 15.3811C186.422 15.3719 186.596 15.2974 186.775 15.2202C186.982 15.1314 187.197 15.0391 187.532 15.0391C187.856 15.0391 188.061 15.129 188.259 15.2153C188.446 15.2973 188.626 15.376 188.893 15.3712C189.461 15.3613 189.819 14.8558 190.166 14.3403C190.542 13.7871 190.706 13.2472 190.731 13.1652L190.734 13.1557C190.734 13.1551 190.729 13.153 190.721 13.1492C190.596 13.0911 189.637 12.6469 189.628 11.4557C189.619 10.4559 190.388 9.94938 190.509 9.86964L190.509 9.86963C190.517 9.86478 190.522 9.86151 190.524 9.8598C190.034 9.12627 189.27 9.04697 189.006 9.02715ZM200.478 15.3761C201.222 15.3761 201.913 14.9945 202.226 14.3898H202.25V15.3166H203.347V11.4706C203.347 10.3554 202.466 9.63672 201.11 9.63672C199.851 9.63672 198.921 10.3653 198.887 11.3665H199.954C200.042 10.8907 200.478 10.5784 201.075 10.5784C201.8 10.5784 202.206 10.9204 202.206 11.5499V11.9761L200.728 12.0653C199.352 12.1496 198.608 12.7195 198.608 13.7108C198.608 14.712 199.376 15.3761 200.478 15.3761ZM200.796 14.4592C200.165 14.4592 199.763 14.1519 199.763 13.6811C199.763 13.1954 200.15 12.9129 200.889 12.8682L202.206 12.784V13.2201C202.206 13.9438 201.599 14.4592 200.796 14.4592ZM206.985 15.619C206.51 16.9721 205.967 17.4181 204.811 17.4181C204.723 17.4181 204.429 17.4082 204.361 17.3884V16.4616C204.434 16.4715 204.615 16.4814 204.708 16.4814C205.232 16.4814 205.526 16.2584 205.707 15.6785L205.815 15.3365L203.807 9.71109H205.046L206.442 14.2758H206.466L207.862 9.71109H209.066L206.985 15.619ZM194.123 8.6009H195.489C196.517 8.6009 197.104 9.156 197.104 10.1324C197.104 11.1088 196.517 11.6688 195.484 11.6688H194.123V8.6009Z"
                fill="black"></path>
            </svg>
          </div>
          <div class="cart-page-delivery-box-main">
            <?php
            $delivery_information_popup = get_field('delivery_information_popup', 'option');
            $delivery_description = $delivery_information_popup['description'] ?? '';

            $delivery_dates = get_field('delivery_dates', 'option');
            $plain_orders = $delivery_dates['plain_orders'] ?? '';
            $branded_orders = $delivery_dates['branded_orders'] ?? '';

            $info_tooltip = get_field('info_tooltip', 'option');
            $info_description = $info_tooltip['description'] ?? '';

            // Function to add working days
            function get_future_date($days)
            {
              if (!is_numeric($days))
                return '';
              $date = new DateTime();
              $added = 0;
              while ($added < $days) {
                $date->modify('+1 day');
                // Delivery according to skip sat,sun
                // 1 = Monday 2 = Tuesday 3 = Wednesday 4 = Thursday 5 = Friday 6 = Saturday 7 = Sunday
                if (!in_array($date->format('N'), [6, 7])) {
                  $added++;
                }
                // Delivery according to all days
                // if (!in_array($date->format('N'), [])) {
                //   $added++;
                // }
              }
              return $date->format('d/m/Y');
            }

            $plain_arrival = get_future_date($plain_orders);
            $branded_arrival = get_future_date($branded_orders);
            ?>

            <div class="delivery-box">
              <div class="delivery-header">
                <span class="clender-icon-text"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="21"
                    viewBox="0 0 20 21" fill="none">
                    <path
                      d="M16.25 3.625H3.75C3.40482 3.625 3.125 3.90482 3.125 4.25V16.75C3.125 17.0952 3.40482 17.375 3.75 17.375H16.25C16.5952 17.375 16.875 17.0952 16.875 16.75V4.25C16.875 3.90482 16.5952 3.625 16.25 3.625Z"
                      stroke="var(--secondary-color)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    </path>
                    <path d="M13.75 2.375V4.875" stroke="var(--secondary-color)" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round"></path>
                    <path d="M6.25 2.375V4.875" stroke="var(--secondary-color)" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round"></path>
                    <path d="M3.125 7.375H16.875" stroke="var(--secondary-color)" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round"></path>
                    <path
                      d="M10 11.5938C10.4315 11.5938 10.7812 11.244 10.7812 10.8125C10.7812 10.381 10.4315 10.0312 10 10.0312C9.56853 10.0312 9.21875 10.381 9.21875 10.8125C9.21875 11.244 9.56853 11.5938 10 11.5938Z"
                      fill="var(--secondary-color)"></path>
                    <path
                      d="M13.4375 11.5938C13.869 11.5938 14.2188 11.244 14.2188 10.8125C14.2188 10.381 13.869 10.0312 13.4375 10.0312C13.006 10.0312 12.6562 10.381 12.6562 10.8125C12.6562 11.244 13.006 11.5938 13.4375 11.5938Z"
                      fill="var(--secondary-color)"></path>
                    <path
                      d="M6.5625 14.7188C6.99397 14.7188 7.34375 14.369 7.34375 13.9375C7.34375 13.506 6.99397 13.1562 6.5625 13.1562C6.13103 13.1562 5.78125 13.506 5.78125 13.9375C5.78125 14.369 6.13103 14.7188 6.5625 14.7188Z"
                      fill="var(--secondary-color)"></path>
                    <path
                      d="M10 14.7188C10.4315 14.7188 10.7812 14.369 10.7812 13.9375C10.7812 13.506 10.4315 13.1562 10 13.1562C9.56853 13.1562 9.21875 13.506 9.21875 13.9375C9.21875 14.369 9.56853 14.7188 10 14.7188Z"
                      fill="var(--secondary-color)"></path>
                    <path
                      d="M13.4375 14.7188C13.869 14.7188 14.2188 14.369 14.2188 13.9375C14.2188 13.506 13.869 13.1562 13.4375 13.1562C13.006 13.1562 12.6562 13.506 12.6562 13.9375C12.6562 14.369 13.006 14.7188 13.4375 14.7188Z"
                      fill="var(--secondary-color)"></path>
                  </svg> Delivery</span>
                <span class="delivery-link" onclick="showModal()">Delivery information</span>
              </div>

              <div class="delivery-info">
                <?php if ($plain_arrival): ?>
                  <div class="info-row">Plain Orders - <strong>Arrives by <?= $plain_arrival ?></strong></div>
                <?php endif; ?>

                <?php if ($branded_arrival): ?>
                  <div class="info-row">Branded Orders - <strong>Arrives by <?= $branded_arrival ?></strong></div>
                <?php endif; ?>

                <div class="info-row tooltip-row">
                  <?php if ($info_description): ?>
                    <span class="tooltip-icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                        <path
                          d="M10 2.375C8.39303 2.375 6.82214 2.85152 5.486 3.74431C4.14985 4.6371 3.10844 5.90605 2.49348 7.3907C1.87852 8.87535 1.71762 10.509 2.03112 12.0851C2.34463 13.6612 3.11846 15.1089 4.25476 16.2452C5.39106 17.3815 6.8388 18.1554 8.4149 18.4689C9.99099 18.7824 11.6247 18.6215 13.1093 18.0065C14.594 17.3916 15.8629 16.3502 16.7557 15.014C17.6485 13.6779 18.125 12.107 18.125 10.5C18.1227 8.34581 17.266 6.28051 15.7427 4.75727C14.2195 3.23403 12.1542 2.37727 10 2.375ZM9.6875 6.125C9.87292 6.125 10.0542 6.17998 10.2084 6.283C10.3625 6.38601 10.4827 6.53243 10.5536 6.70373C10.6246 6.87504 10.6432 7.06354 10.607 7.2454C10.5708 7.42725 10.4815 7.5943 10.3504 7.72541C10.2193 7.85652 10.0523 7.94581 9.8704 7.98199C9.68854 8.01816 9.50004 7.99959 9.32874 7.92864C9.15743 7.85768 9.01101 7.73752 8.908 7.58335C8.80499 7.42918 8.75 7.24792 8.75 7.0625C8.75 6.81386 8.84878 6.5754 9.02459 6.39959C9.20041 6.22377 9.43886 6.125 9.6875 6.125ZM10.625 14.875C10.2935 14.875 9.97554 14.7433 9.74112 14.5089C9.5067 14.2745 9.375 13.9565 9.375 13.625V10.5C9.20924 10.5 9.05027 10.4342 8.93306 10.3169C8.81585 10.1997 8.75 10.0408 8.75 9.875C8.75 9.70924 8.81585 9.55027 8.93306 9.43306C9.05027 9.31585 9.20924 9.25 9.375 9.25C9.70652 9.25 10.0245 9.3817 10.2589 9.61612C10.4933 9.85054 10.625 10.1685 10.625 10.5V13.625C10.7908 13.625 10.9497 13.6908 11.0669 13.8081C11.1842 13.9253 11.25 14.0842 11.25 14.25C11.25 14.4158 11.1842 14.5747 11.0669 14.6919C10.9497 14.8092 10.7908 14.875 10.625 14.875Z"
                          fill="var(--secondary-color)"></path>
                      </svg>
                      <span class="tooltip-text">
                        <?= $info_description ?>
                      </span>
                    </span>
                  <?php endif; ?>
                  <span>If you need it sooner, speak to our team</span>
                </div>
              </div>
            </div>

            <!-- deliverymodal -->
            <?php if ($delivery_description): ?>
              <div id="deliveryModal" class="deliverymodal">
                <div class="deliverymodal-inner">
                  <div class="deliverymodal-content">
                    <div class="deliverymodal-header-flex">
                      <h3>Delivery Information</h3>
                      <div><span class="deliverymodal-close" onclick="closeModal()">&times;</span></div>
                    </div>
                    <div class="modal-body-content">
                      <div class="modal-body-content-inner">
                        <?= $delivery_description ?>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>